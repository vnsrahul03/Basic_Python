from configparser import ConfigParser

class ConfigManager():
	def __init__(self,path):
		print('\nConfig File is given as: ' +path)
		self.config = ConfigParser()
		self.config.read(path)
		
		self.logDirectory 	= self.config['LOGGER_PARAM']['LOG_DIRECTORY']
		self.Log_Level 		= self.config['LOGGER_PARAM']['LOGGER_LEVEL']
		self.LogFilename 	= self.config['LOGGER_PARAM']['LOG_FILENAME']
		
		self.gcp_project_id     	= self.config['GCP_PARAM']['GCP_PROJECT_ID']
		self.gcp_key_path     		= self.config['GCP_PARAM']['GCP_KEY_PATH']
		self.gcp_dataset_name   	= self.config['GCP_PARAM']['DATASET_NAME']
		self.gcp_connect_flag     	= self.config['GCP_PARAM']['CONNECT_WITH_GCP_FLAG']
		self.sale_start_date    	= self.config['GCP_PARAM']['SALE_START_DATE']
		self.sale_end_date     		= self.config['GCP_PARAM']['SALE_END_DATE']
		self.gcp_range_filename 	= self.config['GCP_PARAM']['GCP_RANGE_FILENAME']
		self.gcp_range_filepath     = self.config['GCP_PARAM']['GCP_RANGE_FILEPATH']
		self.gcp_range_sheet     	= self.config['GCP_PARAM']['GCP_RANGE_SHEET_NAME']
		
		
		self.business_file_1_name     = self.config['BUSINESS_FILE_1_PARAM']['FILENAME_1']
		self.business_file_1_path     = self.config['BUSINESS_FILE_1_PARAM']['FILEPATH_1']
		self.business_file_1_sheet    = self.config['BUSINESS_FILE_1_PARAM']['FILE_1_SHEET_NAME']
		self.business_file_1_date     = self.config['BUSINESS_FILE_1_PARAM']['FILE_1_DATE']
		self.business_file_1_run_flag = self.config['BUSINESS_FILE_1_PARAM']['PROCESS_1_RUN_FLAG']
		
		self.business_file_2_name     = self.config['BUSINESS_FILE_2_PARAM']['FILENAME_2']
		self.business_file_2_path     = self.config['BUSINESS_FILE_2_PARAM']['FILEPATH_2']
		self.business_file_2_sheet    = self.config['BUSINESS_FILE_2_PARAM']['FILE_2_SHEET_NAME']
		self.business_file_2_date     = self.config['BUSINESS_FILE_2_PARAM']['FILE_2_DATE']
		self.business_file_2_run_flag = self.config['BUSINESS_FILE_2_PARAM']['PROCESS_2_RUN_FLAG']
		
		self.business_file_3_name     = self.config['BUSINESS_FILE_3_PARAM']['FILENAME_3']
		self.business_file_3_path     = self.config['BUSINESS_FILE_3_PARAM']['FILEPATH_3']
		self.business_file_3_sheet    = self.config['BUSINESS_FILE_3_PARAM']['FILE_3_SHEET_NAME']
		self.business_file_3_date     = self.config['BUSINESS_FILE_3_PARAM']['FILE_3_DATE']
		self.business_file_3_run_flag = self.config['BUSINESS_FILE_3_PARAM']['PROCESS_3_RUN_FLAG']
		
		self.output_filepath     	= self.config['OUTPUT_PARAM']['OUTPUT_FILEPATH']
		self.success_path     		= self.config['OUTPUT_PARAM']['SUCCESS_PATH']
		self.failure_path     		= self.config['OUTPUT_PARAM']['FAILURE_PATH']
		self.bus_file_1_substr     	= self.config['OUTPUT_PARAM']['BUSINESS_FILE_1_SUBSTR']
		self.bus_file_1_delimiter   = self.config['OUTPUT_PARAM']['BUSINESS_FILE_1_DELIMITER']
		self.bus_file_2_substr     	= self.config['OUTPUT_PARAM']['BUSINESS_FILE_2_SUBSTR']
		self.bus_file_2_delimiter   = self.config['OUTPUT_PARAM']['BUSINESS_FILE_2_DELIMITER']
		self.bus_file_3_substr     	= self.config['OUTPUT_PARAM']['BUSINESS_FILE_3_SUBSTR']
		self.bus_file_3_delimiter   = self.config['OUTPUT_PARAM']['BUSINESS_FILE_3_DELIMITER']
		
		
		
	def printConfig(self):
		pass
		#TBD
