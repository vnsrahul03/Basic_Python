import logging

class logger_function :
     def log_message(log_level,logFilename,logdir):
	 
        if(int(log_level)==5): 
          obj_Log=logging.basicConfig(filename= logdir+logFilename,filemode='a',format='%(asctime)s |LEVEL_%(levelname)s : %(message)s | [%(filename)s:%(lineno)d]', level=logging.DEBUG)

        elif(int(log_level)==4):
          obj_Log= logging.basicConfig(filename= logdir+logFilename,filemode='a',format='%(asctime)s |LEVEL_%(levelname)s : %(message)s | [%(filename)s:%(lineno)d]', level=logging.INFO)

        elif(int(log_level)==3):
          obj_Log= logging.basicConfig(filename= logdir+logFilename,filemode='a',format='%(asctime)s |LEVEL_%(levelname)s  : %(message)s | [%(filename)s:%(lineno)d]', level=logging.WARNING)

        elif(int(log_level)==2):
          obj_Log= logging.basicConfig(filename= logdir+logFilename,filemode='a',format='%(asctime)s |LEVEL_%(levelname)s  : %(message)s | [%(filename)s:%(lineno)d]', level=logging.ERROR)

        elif(int(log_level)==1):
          obj_Log= logging.basicConfig(filename= logdir+logFilename,filemode='a',format='%(asctime)s |LEVEL_%(levelname)s  : %(message)s | [%(filename)s:%(lineno)d]', level=logging.CRITICAL)
          
        return obj_Log