# importing libraries pip freeze  C:\Users\compaq pc\AppData\Roaming\Notepad++\backup
import os
import sys 
import Configuration
import logging
import Logger
import datetime
import CB_Automate as cb
import traceback

def main(argv):
	try:
		print('\n***************** CB Automation Process Started ********************************')
		print('\nArgument 1 is given as : '+argv[0])
		print('\nArgument 2 is given as : '+argv[1])
		#Config Initialization
		objConfigManager = Configuration.ConfigManager(argv[1])
		#Logger Initialization
		now=datetime.datetime.now()
		dt=now.strftime('%d%m%Y_%H_%M')
		substr='.log'
		logFilename=objConfigManager.LogFilename
		finalFilename=logFilename.replace(substr,'_'+dt+substr)
		Logger.logger_function.log_message(str(objConfigManager.Log_Level),finalFilename,objConfigManager.logDirectory)
		logging.info('Logging Parameters Initialized Successfully')
		objCBAutomate=cb.automateCB(objConfigManager)
		if(objConfigManager.business_file_1_run_flag not in['Y','N']):
			logging.info('PROCESS_1_RUN_FLAG Either set to Y or N. So, Skipping CBAutomationMain Process.')
			print('\n PROCESS_1_RUN_FLAG Either set to Y or N. So, Skipping CBAutomationMain Process.')
			sys.exit(1)
		elif(objConfigManager.business_file_2_run_flag not in['Y','N']):
			logging.info('PROCESS_2_RUN_FLAG Either set to Y or N. So, Skipping CBAutomationMain Process.')
			print('\n PROCESS_1_RUN_FLAG Either set to Y or N. So, Skipping CBAutomationMain Process.')
			sys.exit(1)
		elif(objConfigManager.business_file_3_run_flag not in['Y','N']):
			logging.info('PROCESS_3_RUN_FLAG Either set to Y or N. So, Skipping CBAutomationMain Process.')
			print('\n PROCESS_1_RUN_FLAG Either set to Y or N. So, Skipping CBAutomationMain Process.')
			sys.exit(1)
		#TODO except Y or N flag case handle
		else:
			if(objConfigManager.business_file_1_run_flag =='Y' and objConfigManager.business_file_2_run_flag =='Y' and objConfigManager.business_file_3_run_flag =='Y'):
				logging.info('All three Flags is set to Y. So, Skipping CBAutomationMain Process.')
				print('\n All three Flags is set to Y. So, Skipping CBAutomationMain Process.')
				sys.exit(1)
			elif(objConfigManager.business_file_1_run_flag =='Y' and objConfigManager.business_file_2_run_flag =='Y'):
				logging.info('Flags 1 and 2 is set to Y. So, Skipping CBAutomationMain Process.')
				print('\n Flags 1 and 2 is set to Y. So, Skipping CBAutomationMain Process.')
				sys.exit(1)
			elif(objConfigManager.business_file_1_run_flag =='Y' and objConfigManager.business_file_3_run_flag =='Y'):
				logging.info('Flags 1 and 3 is set to Y. So, Skipping CBAutomationMain Process.')
				print('\n Flags 1 and 3 is set to Y. So, Skipping CBAutomationMain Process.')
				sys.exit(1)
			elif(objConfigManager.business_file_2_run_flag =='Y' and objConfigManager.business_file_3_run_flag =='Y'):
				logging.info('Flags 2 and 3 is set to Y. So, Skipping CBAutomationMain Process.')
				print('\n Flags 2 and 3 is set to Y. So, Skipping CBAutomationMain Process.')
				sys.exit(1)
			else:
				if(objConfigManager.business_file_1_run_flag =='Y'):
					print('\n*****************Starting CB Mapping First Time Process**********')
					Retcode = objCBAutomate.processBusiness_1File()
					
				elif(objConfigManager.business_file_2_run_flag =='Y'):
					print('\n*****************Starting CB Group Ratio Mapping Process**********')
					Retcode = objCBAutomate.processBus_Ratio_2File()
				
				elif(objConfigManager.business_file_3_run_flag =='Y'):
					print('\n*****************Starting CB Mapping Second Time Process**********')
					Retcode = objCBAutomate.processBusiness_3File()
					
				else:
					logging.info('None of Flag is set to Y. So, Skipping CBAutomationMain Process.')
					print('\n***************** None of Flag is set to Y. So, Skipping CBAutomationMain Process. *****************')
					sys.exit(1)
				print('\n-----------------------------: '+Retcode+' :---------------------------------------')
				if(Retcode != 'SUCCESS'):
					logging.error('There is an Error in Executing CB Automation Process')
					print('\n There is an Error in Executing CB Automation Process. Check the Logs For more......')
					sys.exit(1)
				else:
					logging.info('CBAutomationMain Process Executed Successfully.')
					print('\n***************** CB Automation Process Executed Successfully*****************')
					sys.exit(0)
	
	except Exception as exp:
		print('\n Main Caught an Exception : {0}'.format(exp))
		print('\n ---Print Traceback Start----')
		print(traceback.format_exc())
		print('\n ---Print Traceback End----')
		logging.error('Main Caught an Exception : {0}'.format(exp))
		logging.error('---Print Traceback Start----')
		logging.error(traceback.format_exc())
		logging.error('---Print Traceback End----')
		return 1
		
if __name__=='__main__':
	
	if len(sys.argv) != 2:
		print('\n Usage: CBAutomationMain <Config File>')
		print('\n Run Again With Correct Parameters')
		sys.exit(1)
	
	else :
		main(sys.argv)
	
	
	
	