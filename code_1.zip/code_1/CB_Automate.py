import os 
import Configuration
import logging
import Logger
import pandas as pd
import datetime
import traceback
import shutil

class automateCB():
	def __init__(self,objConfigManager):
		
		self.objConfigManager = objConfigManager
	
	def processBusiness_1File(self):
		try:
			logging.debug('Entering in processBusiness_1File() function')
			fileName_1 = self.objConfigManager.business_file_1_name
			bus_1_Path = self.objConfigManager.business_file_1_path
			bus_1_fileName = fileName_1.replace('@',self.objConfigManager.business_file_1_date)
			bus_1_file = bus_1_Path + bus_1_fileName
			logging.info('BUSINESS_FILE_1 Parameters Initialized Successfully with file is given as: {0}'.format(bus_1_fileName))
			logging.debug('Checking availability of BUSINESS_FILE_1 in directory: {0}'.format(bus_1_Path))
			if os.path.isfile(bus_1_file):
				logging.debug('BUSINESS_FILE_1 found as :{0}'.format(bus_1_file))
				Business_1_xls_file = pd.ExcelFile(bus_1_file)
				tempDFUserFile1 = pd.read_excel(Business_1_xls_file,self.objConfigManager.business_file_1_sheet)
				if not 'item_number' in  tempDFUserFile1.columns:
					logging.critical('item_number Column not present in file :{0}'.format(bus_1_fileName))
					return 'FAILURE'
				if not 'cb_maingroup' in  tempDFUserFile1.columns:
					logging.critical('cb_maingroup Column not present in file :{0}'.format(bus_1_fileName))
					return 'FAILURE'
				if not 'cb_subgroup' in  tempDFUserFile1.columns:
					logging.critical('cb_subgroup Column not present in file :{0}'.format(bus_1_fileName))
					return 'FAILURE'
				else:	
					logging.debug('Validation Check Executed Successfully for file :{0}'.format(bus_1_fileName))
					tempDFUserFile1 = tempDFUserFile1.loc[:, ~tempDFUserFile1.columns.str.contains('^Unnamed')]
					tempDFUserFile1 = tempDFUserFile1.loc[:,['item_number','cb_maingroup','cb_subgroup']]
					tempDFUserFile1=tempDFUserFile1.fillna('')
					tempDFUserFile1.rename(columns={'item_number':'cb_item_number'}, inplace=True)
					logging.info('BUSINESS_FILE_1 Data Populated Successfully in Dataset with Length as : {0}'.format(len(tempDFUserFile1.index)))
				if(self.objConfigManager.gcp_connect_flag =='Y'):
					logging.debug('Since CONNECT_WITH_GCP_FLAG is set to Y. Hence, Connecting with GCP BigQuery')
					#Retrieve data from gcp range table and create a csv file so that we can use further
					return 'SUCCESS'
					
				elif(self.objConfigManager.gcp_connect_flag =='N'):
					logging.debug('Since CONNECT_WITH_GCP_FLAG is set to N. Hence, Skipping Connect with GCP BigQuery and Generating CSV Output File')
					out_file1= self.objConfigManager.output_filepath + bus_1_fileName.replace(self.objConfigManager.bus_file_1_substr,'csv')
					logging.info('Output CSV File is given as : {0}'.format(out_file1))
					tempDFUserFile1.to_csv(out_file1,sep = self.objConfigManager.bus_file_1_delimiter,index=False,line_terminator='\n')
					logging.info('Output CSV File Generated Successfully')
					file_range = self.objConfigManager.gcp_range_filename
					file_range_path = self.objConfigManager.gcp_range_filepath
					logging.info('Checking availability of GCP Range file {0} in directory: {1}'.format(file_range,file_range_path))
					gcpFile_range = file_range_path + file_range
					if os.path.isfile(gcpFile_range):
						logging.info('GCP Range File Found as :{0}'.format(gcpFile_range))
						gcp_xls_file = pd.ExcelFile(gcpFile_range)
						dfGCPDataExcel = pd.read_excel(gcp_xls_file,self.objConfigManager.gcp_range_sheet)
						dfGCPDataExcel = dfGCPDataExcel.loc[:, ~dfGCPDataExcel.columns.str.contains('^Unnamed')]
						dfGCPDataExcel=dfGCPDataExcel.fillna('')
						logging.info('GCP Data Populated Successfully in DataFrame with Length as : {0}'.format(len(dfGCPDataExcel.index)))
						dfGCPDataExcel = dfGCPDataExcel.astype('str')
						tempDFUserFile1 = tempDFUserFile1.astype('str')
						tempDFUserFile1['cb_item_number'].str.replace(' ','')
						dfConsolidate = pd.merge(left=tempDFUserFile1,right=dfGCPDataExcel,how='right',left_on ='cb_item_number',right_on='item_number',indicator=False)
						dfConsolidate=dfConsolidate.fillna('')
						new_order=['item_number','item_type','item_name','item_endletter_two','item_caption','product_area_number','product_area_name',
								 'product_area_caption','product_range_area_number','product_range_area_name','product_range_area_caption',
								 'home_furnishing_business_number','home_furnishing_business_name','home_furnishing_business_caption',
								 'sale_start_date','sale_end_date','cb_item_number','cb_maingroup','cb_subgroup']
						dfConsolidate = dfConsolidate.reindex(columns=new_order)
						#print(dfConsolidate)
						logging.info('Consolidate Data Populated Successfully in DataFrame with Length as : {0}'.format(len(dfConsolidate.index)))
						consolidate_filename = self.objConfigManager.output_filepath+ self.objConfigManager.business_file_1_name.replace('@',self.objConfigManager.business_file_1_date)
						logging.info('Output Consolidate File is given as : {0}'.format(consolidate_filename))
						dataToExcel = pd.ExcelWriter(consolidate_filename)
						dfConsolidate.to_excel(dataToExcel,sheet_name='sheet1',header=True,index=False)
						dataToExcel.save()
						#dfConsolidate.to_csv(consolidate_filename,index=False,line_terminator='\n')
						logging.info('Output Consolidate File Generated Successfully')
						if os.path.isfile(consolidate_filename):
							logging.info('Output File Generated Successfully as : {0}'.format(consolidate_filename))
							return 'SUCCESS'
						else:
							logging.error('Their is an Error in Generating Consolidate Report File: {0}'.format(consolidate_filename))
							return 'FAILURE'
					else:
						logging.error('GCP Range File: {0} not Found in the path :{1}'.format(file_range,file_range_path))
						return 'FAILURE'
			else:
				logging.critical('BUSINESS_FILE_1 : {0} doesnot exist in the path: {1}'.format(bus_1_fileName,bus_1_Path))
				return 'FAILURE'
		except Exception as exp:
			logging.error('An exception occured in processBusiness_1File() as : {0}'.format(exp))
			logging.error('---Print Traceback Start----')
			logging.error(traceback.format_exc())
			logging.error('---Print Traceback End----')
			return 'FAILURE'
		
	def processBus_Ratio_2File(self):
		try:
			logging.debug('Entering in processBus_Ratio_2File() function')
			fileName_2 = self.objConfigManager.business_file_2_name
			bus_2_Path = self.objConfigManager.business_file_2_path
			bus_2_fileName = fileName_2.replace('@',self.objConfigManager.business_file_2_date)
			bus_2_file = bus_2_Path + bus_2_fileName
			logging.info('BUSINESS_FILE_2 Parameters Initialized Successfully with file is given as: {0}'.format(bus_2_fileName))
			logging.debug('Checking availability of CB_Group_Ratio_Mapping file in directory: {0}'.format(bus_2_Path))
			if os.path.isfile(bus_2_file):
				logging.debug('CB_Group_Ratio_Mapping file found as :{0}'.format(bus_2_file))
				Business_2_xls_file = pd.ExcelFile(bus_2_file)
				tempDFUserFile2 = pd.read_excel(Business_2_xls_file,self.objConfigManager.business_file_2_sheet)
				if not 'Group Ratio' in  tempDFUserFile2.columns:
					logging.critical('Group Ratio Column not present in file :{0}'.format(bus_2_fileName))
					return 'FAILURE'
				if not 'Commercial Benchmarking Group 1' in  tempDFUserFile2.columns:
					logging.critical('Commercial Benchmarking Group 1 Column not present in file :{0}'.format(bus_2_fileName))
					return 'FAILURE'
				if not 'Commercial Benchmarking Group 2' in  tempDFUserFile2.columns:
					logging.critical('Commercial Benchmarking Group 2 Column not present in file :{0}'.format(bus_2_fileName))
					return 'FAILURE'
				else:	
					logging.debug('Validation Check Executed Successfully for file :{0}'.format(bus_2_fileName))
					tempDFUserFile2 = tempDFUserFile2.loc[:, ~tempDFUserFile2.columns.str.contains('^Unnamed')]
					tempDFUserFile2 = tempDFUserFile2.loc[:,['Group Ratio','Commercial Benchmarking Group 1','Commercial Benchmarking Group 2']]
					tempDFUserFile2=tempDFUserFile2.fillna('')
					logging.info('CB_Group_Ratio_Mapping File Data Populated Successfully in Dataset with Length as : {0}'.format(len(tempDFUserFile2.index)))
					if(self.objConfigManager.gcp_connect_flag =='Y'):
						logging.debug('Since CONNECT_WITH_GCP_FLAG is set to Y. Hence, Connecting with GCP BigQuery')
						return 'SUCCESS'
					elif(self.objConfigManager.gcp_connect_flag =='N'):
						logging.debug('Since CONNECT_WITH_GCP_FLAG is set to N. Hence, Skipping Connect with GCP BigQuery and Generating Output CSV File')
						out_file2= self.objConfigManager.output_filepath + bus_2_fileName.replace(self.objConfigManager.bus_file_2_substr,'csv')
						logging.info('Output CSV File is given as : {0}'.format(out_file2))
						tempDFUserFile2.to_csv(out_file2,sep = self.objConfigManager.bus_file_2_delimiter,index = False,line_terminator='\n')
						logging.info('Output CSV File Generated Successfully')
						return 'SUCCESS'
					else:
						logging.critical('Invalid CONNECT_WITH_GCP_FLAG is set : {0}. Hence, Exiting the Process'.format(self.objConfigManager.gcp_connect_flag))
						return 'FAILURE'
			else:
				logging.critical('CB_Group_Ratio_Mapping File : {0} doesnot exist in the path: {1}'.format(bus_2_fileName,bus_2_Path))
				return 'FAILURE'
		except Exception as exp:
			logging.error('An exception occured in processBus_Ratio_2File() as : {0}'.format(exp))
			logging.error('---Print Traceback Start----')
			logging.error(traceback.format_exc())
			logging.error('---Print Traceback End----')
			return 'FAILURE'
			
	def processBusiness_3File(self):
		try:
			logging.debug('Entering in processBusiness_3File() function')
			fileName_3 = self.objConfigManager.business_file_3_name
			bus_3_Path = self.objConfigManager.business_file_3_path
			bus_3_fileName = fileName_3.replace('@',self.objConfigManager.business_file_3_date)
			bus_3_file = bus_3_Path + bus_3_fileName
			logging.info('BUSINESS_FILE_3 Parameters Initialized Successfully with file is given as: {0}'.format(bus_3_fileName))
			logging.debug('Checking availability of BUSINESS_FILE_3 in directory: {0}'.format(bus_3_Path))
			if os.path.isfile(bus_3_file):
				logging.debug('BUSINESS_FILE_3 found as :{0}'.format(bus_3_file))
				Business_3_xls_file = pd.ExcelFile(bus_3_file)
				tempDFUserFile3 = pd.read_excel(Business_3_xls_file,self.objConfigManager.business_file_3_sheet)
				if not 'item_number' in  tempDFUserFile3.columns:
					logging.critical('item_number Column not present in file :{0}'.format(bus_3_fileName))
					return 'FAILURE'
				if not 'cb_maingroup' in  tempDFUserFile3.columns:
					logging.critical('cb_maingroup Column not present in file :{0}'.format(bus_3_fileName))
					return 'FAILURE'
				if not 'cb_subgroup' in  tempDFUserFile3.columns:
					logging.critical('cb_subgroup Column not present in file :{0}'.format(bus_3_fileName))
					return 'FAILURE'
				else:	
					logging.debug('Validation Check Executed Successfully for file :{0}'.format(bus_3_fileName))
					tempDFUserFile3 = tempDFUserFile3.loc[:, ~tempDFUserFile3.columns.str.contains('^Unnamed')]
					tempDFUserFile3 = tempDFUserFile3.loc[:,['item_number','cb_maingroup','cb_subgroup']]
					tempDFUserFile3=tempDFUserFile3.fillna('')
					tempDFUserFile3.rename(columns={'item_number':'cb_item_number'}, inplace=True)
					logging.info('BUSINESS_FILE_3 Data Populated Successfully in Dataset with Length as : {0}'.format(len(tempDFUserFile3.index)))
					if(self.objConfigManager.gcp_connect_flag =='Y'):
						logging.debug('Since CONNECT_WITH_GCP_FLAG is set to Y. Hence, Connecting with GCP BigQuery')
						return 'SUCCESS'
					elif(self.objConfigManager.gcp_connect_flag =='N'):
						logging.debug('Since CONNECT_WITH_GCP_FLAG is set to N. Hence, Skipping Connect with GCP BigQuery and Generating Output CSV File')
						out_file3= self.objConfigManager.output_filepath + bus_3_fileName.replace(self.objConfigManager.bus_file_3_substr,'csv')
						logging.info('Output CSV File is given as : {0}'.format(out_file3))
						tempDFUserFile3.to_csv(out_file3,sep = self.objConfigManager.bus_file_3_delimiter,index = False,line_terminator='\n')
						logging.info('Output CSV File Generated Successfully')
						return 'SUCCESS'
					else:
						logging.critical('Invalid CONNECT_WITH_GCP_FLAG is set : {0}. Hence, Exiting the Process'.format(self.objConfigManager.gcp_connect_flag))
						return 'FAILURE'
			else:
				logging.critical('BUSINESS_FILE_3 : {0} doesnot exist in the path: {1}'.format(bus_3_fileName,bus_3_Path))
				return 'FAILURE'
		except Exception as exp:
			logging.error('An exception occured in processBusiness_3File() as : {0}'.format(exp))
			logging.error('---Print Traceback Start----')
			logging.error(traceback.format_exc())
			logging.error('---Print Traceback End----')
			return 'FAILURE'
			
	def moveFiles(self,srcPath,destPath):
		try:
			logging.debug('Entering in processBus_Ratio_2File() function')
			logging.debug('Source file is given as : {0} and Destination is given as : {1}'.format(srcPath,destPath))
			retvalue=shutil.move(srcPath,destPath)
			logging.debug('File move Successfully'.format(srcPath,destPath))
			return 'SUCCESS'
		except Exception as ex:
			logging.error('An exception occured in moveFiles() as : {0}'.format(ex))
			logging.error('---Print Traceback Start----')
			logging.error(traceback.format_exc())
			logging.error('---Print Traceback End----')
			return 'FAILURE'